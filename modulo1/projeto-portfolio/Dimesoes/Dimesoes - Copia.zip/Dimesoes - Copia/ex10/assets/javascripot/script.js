function alterar() {
    if (document.getElementById)
}